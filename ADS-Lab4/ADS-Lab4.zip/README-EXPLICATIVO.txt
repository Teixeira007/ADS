/Arquivos R - uma pasta com o arquivo R e todos os txt_filt
/couting - uma pasta com todos os txt gerados do algoritmo counting
/merge - uma pasta com todos os txt gerados do algoritmo merge
/quick - uma pasta com todos os txt gerados do algoritmo quick

/Script - uma pasta com todos os scripts utilizados
quick - um script que utilizei para gerar todos os txt necessarios para avaliar o algorimo quick
merge - um script que utilizei para gerar todos os txt necessarios para avaliar o algorimo merge
counting - um script que utilizei para gerar todos os txt necessarios para avaliar o algorimo counting
juntarTudo - script para juntar todos os arquivos em apenas um txt, esse script precisa está na pasta 
dos txts para ser executado as pastas com os txts são /counting, /merge, e /quick



Fiz todos esses scripts utilizado arquivos .bat, que são arquivos em lotes utilizados no sistema operacional Windows
para automatizar tarefas repetitivas. 